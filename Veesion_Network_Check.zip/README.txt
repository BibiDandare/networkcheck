**--    -- -------- -------- -------- --  ------  ---    --**  
**--    -- --       --       --       -- --    -- ----   --**  
**--    -- -----    -----    -------- -- --    -- -- --  --**  
** --  --  --       --            --  -- --    -- --  -- --**  
**  ----   -------- -------  -------- --  ------  --   ---- **


# Script PowerShell : Vérification de Connectivité et Suivi des Tâches

## Description
Ce script PowerShell permet de tester la connectivité réseau, télécharger des outils nécessaires, et afficher une interface graphique. 

### Fonctionnalités :
1. Vérification et relance automatique en mode administrateur.
2. Test de connectivité réseau sur différents ports et adresses.
3. Téléchargement et exécution de l'outil "Speedtest CLI" pour tester les performances réseau.
4. Barre de progression visuelle et mise à jour en temps réel via une interface utilisateur.
5. Journaux des résultats stockés dans un fichier de logs : "networkcheck_logs.txt".
6. Affichage d'un pop-up indiquant le début et la fin de l'exécution de l'éxécutable "networkcheck.exe.

---

## Prérequis

- **PowerShell** : Version 5.1 ou supérieure.
- **Système Windows** avec .NET Framework pour l'interface graphique.
- **Droits d'administrateur** : nécessaires pour certaines opérations réseau et l'écriture dans certains répertoires.

---

## Installation et utilisation 

1. Téléchargez le fichier du script ("Veesion_Network_Check").
2. Décompresser le fichier dans le répertoire sur votre machine.
3. Lancer l'éxecutable ("networkcheck.exe") en mode administrateur, et suivez les instructions

---

## Fonctionnalités détaillées

### Tests de connectivité
Le script vérifie l'état des ports sur différentes adresses :
- Ports testés : `80`, `53`, `443`, `5671`.
- Adresses testées : `www.google.com`, `8.8.8.8`, `messaging.veesion.io`, etc.

### Récupérations d'informations réseau Local
Le script récupère :
- Adressage réseau de la machine. 
- L'état du serveur DHCP.

### Téléchargement et exécution du Speedtest CLI

- Télécharge "Speedtest CLI" depuis une URL officielle.
- Décompresse les fichiers et exécute un test de débit réseau.


### Journalisation

Les résultats sont enregistrés dans un fichier de log situé dans :
```
C:\Users\<Utilisateur>\Downloads\Veesion_Network_Check\networkcheck.txt
```

## Résultats attendus

### Affichage console / GUI
- Une barre de progression indique l'état d'avancement des tâches.
- Un journal est affiché dans la fenêtre GUI, indiquant les étapes et les résultats.

### Journaux
Le fichier de log inclut :
- Les adresses testées et l'état des ports.
- Les résultats du test Speedtest.
- Toute erreur rencontrée.

---

## Dépannage

### Le script ne s'exécute pas
1. Assurez-vous que vous avez les droits d'administrateur.
2. Vérifiez que les permissions sont activées pour exécuter des scripts PowerShell.
3. Désactivez temporaire votre antivirus. 

### Le dossier de logs n'existe pas
Si le script ne peut pas créer le dossier de logs, assurez-vous que vous avez les permissions nécessaires pour écrire dans le répertoire `Downloads`.

---

## Auteur
Créé par Veesion, conçu pour les besoins de vérification de connectivité réseau.
---